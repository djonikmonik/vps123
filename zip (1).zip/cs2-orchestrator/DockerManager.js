const { exec } = require('child_process');

class DockerManager {
    constructor() {
        // In-memory state for MVP. In production, you'd poll `docker ps`
        this.activeContainers = new Set();
    }

    launchAccount(account, clientPort) {
        return new Promise((resolve, reject) => {
            const containerName = `cs2bot_${account.id}`;
            
            // Host paths where you MUST place the SSFN and config.vdf per account
            const botDataPath = `/opt/cs2farm/botdata/${account.id}`;
            const gameFilesPath = `/opt/cs2farm/cs2_game_files`;

            console.log(`[Docker] Firing up container ${containerName}...`);

            // The holy grail payload. 
            // -v mounts the SSFN and config.vdf directly into the container's Steam directory.
            // -v mounts the 35GB game folder as Read-Only (:ro) so 50 bots share 1 copy.
            const dockerCmd = `docker run -d --rm \\
                --name ${containerName} \\
                --cpus="1.0" \\
                -m="1536m" \\
                -e STEAM_USER=${account.login} \\
                -e STEAM_PASS=${account.password} \\
                -e CLIENT_PORT=${clientPort} \\
                -v ${botDataPath}/ssfn:/home/steamuser/.steam/steam/ssfn \\
                -v ${botDataPath}/config.vdf:/home/steamuser/.steam/steam/config/config.vdf \\
                -v ${gameFilesPath}:/home/steamuser/.steam/steam/steamapps/common/Counter-Strike\\ Global\\ Offensive:ro \\
                my-cs2-base-image`;

            exec(dockerCmd, (err, stdout, stderr) => {
                if (err) {
                    console.error(`[Docker] Failed to launch ${containerName}:`, stderr);
                    return reject(new Error(`Docker launch failed: ${stderr}`));
                }
                const containerId = stdout.trim();
                console.log(`[Docker] Container ${containerName} running. ID: ${containerId}`);
                this.activeContainers.add(account.id);
                resolve(containerId);
            });
        });
    }

    stopAccount(accountId) {
        return new Promise((resolve, reject) => {
            const containerName = `cs2bot_${accountId}`;
            console.log(`[Docker] Nuking container ${containerName}...`);
            
            // Hard kill, no graceful shutdown. We don't care about state inside the container.
            exec(`docker stop ${containerName} -t 0`, (err, stdout, stderr) => {
                if (err) {
                    // If it fails to stop, it might already be dead. Just log and remove from set.
                    console.error(`[Docker] Failed to stop ${containerName} (might be dead already):`, stderr);
                } else {
                    console.log(`[Docker] Container ${containerName} annihilated.`);
                }
                this.activeContainers.delete(accountId);
                resolve();
            });
        });
    }

    isRunning(accountId) {
        return this.activeContainers.has(accountId);
    }
}

module.exports = new DockerManager();
