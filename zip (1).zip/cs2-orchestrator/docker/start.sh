#!/bin/bash

# Boot up Xvfb on display :99 with minimum resolution
Xvfb :99 -screen 0 640x480x16 &
export DISPLAY=:99

echo "Starting Steam silently..."
# Launch Steam. If SSFN and config.vdf are mounted correctly, it logs in silently.
./steam.sh -login $STEAM_USER $STEAM_PASS -silent &

# Wait 20 seconds for Steam to catch the network and authenticate
sleep 20

echo "Launching CS2 in textmode..."
# Launch CS2 via protocol
./steam.sh "steam://rungameid/730//-textmode -novid -nosound -low +clientport $CLIENT_PORT"

# Keep the container alive
wait
