document.addEventListener('DOMContentLoaded', () => {
    fetchAccounts();
    // Refresh accounts every 10 seconds to keep 2FA codes and status updated
    setInterval(fetchAccounts, 10000);
});

document.getElementById('addAccountForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const login = document.getElementById('login').value;
    const password = document.getElementById('password').value;
    const shared_secret = document.getElementById('shared_secret').value;
    const msgDiv = document.getElementById('formMessage');

    try {
        const res = await fetch('/api/accounts/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ login, password, shared_secret })
        });
        
        const data = await res.json();
        
        if (data.success) {
            msgDiv.textContent = 'Account added successfully!';
            msgDiv.className = 'mt-4 text-sm text-green-400 block';
            document.getElementById('addAccountForm').reset();
            fetchAccounts();
        } else {
            throw new Error(data.error);
        }
    } catch (err) {
        msgDiv.textContent = err.message;
        msgDiv.className = 'mt-4 text-sm text-red-400 block';
    }
    
    setTimeout(() => { msgDiv.classList.add('hidden'); }, 3000);
});

async function fetchAccounts() {
    try {
        const res = await fetch('/api/accounts');
        const accounts = await res.json();
        
        const tbody = document.getElementById('accountsTableBody');
        tbody.innerHTML = '';
        
        accounts.forEach(acc => {
            const tr = document.createElement('tr');
            tr.className = 'border-b border-gray-700 hover:bg-gray-750';
            
            const statusColor = acc.status === 'running' ? 'text-green-400' : 'text-gray-400';
            
            tr.innerHTML = `
                <td class="py-3">${acc.id}</td>
                <td class="py-3 font-medium">${acc.login}</td>
                <td class="py-3 font-bold ${statusColor}">${acc.status.toUpperCase()}</td>
                <td class="py-3 font-mono text-blue-300 tracking-widest">${acc.current_code}</td>
                <td class="py-3 text-right space-x-2">
                    <button onclick="launchAccount(${acc.id})" class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-xs transition" ${acc.status === 'running' ? 'disabled opacity-50 cursor-not-allowed' : ''}>Launch</button>
                    <button onclick="stopAccount(${acc.id})" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-xs transition" ${acc.status === 'idle' ? 'disabled opacity-50 cursor-not-allowed' : ''}>Stop</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (err) {
        console.error('Failed to fetch accounts:', err);
    }
}

async function launchAccount(id) {
    try {
        const res = await fetch(\`/api/accounts/\${id}/test-launch\`, { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            fetchAccounts();
        } else {
            alert('Launch failed: ' + data.error);
        }
    } catch (err) {
        alert('Error: ' + err.message);
    }
}

async function stopAccount(id) {
    try {
        const res = await fetch(\`/api/accounts/\${id}/stop\`, { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            fetchAccounts();
        } else {
            alert('Stop failed: ' + data.error);
        }
    } catch (err) {
        alert('Error: ' + err.message);
    }
}
