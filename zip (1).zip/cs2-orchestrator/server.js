const express = require('express');
const SteamTotp = require('steam-totp');
const path = require('path');
const db = require('./database');
const dockerManager = require('./DockerManager');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Add a new account
app.post('/api/accounts/add', (req, res) => {
    const { login, password, shared_secret } = req.body;
    
    if (!login || !password || !shared_secret) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    const stmt = db.prepare(`INSERT INTO Accounts (login, password, shared_secret, status) VALUES (?, ?, ?, 'idle')`);
    stmt.run([login, password, shared_secret], function(err) {
        if (err) {
            return res.status(500).json({ error: 'Database error: ' + err.message });
        }
        res.json({ success: true, id: this.lastID });
    });
});

// Get all accounts with current 2FA codes
app.get('/api/accounts', (req, res) => {
    db.all(`SELECT id, login, status, shared_secret, last_drop_time FROM Accounts`, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: 'Database error: ' + err.message });
        }
        
        const accounts = rows.map(row => {
            let current_code = 'Error';
            try {
                // Generate the real-time Steam Guard code
                current_code = SteamTotp.generateAuthCode(row.shared_secret);
            } catch (e) {
                current_code = 'Invalid Secret';
            }
            
            // Sync status with actual docker manager
            const isRunning = dockerManager.isRunning(row.id);
            const actualStatus = isRunning ? 'running' : 'idle';
            
            // Update DB if out of sync
            if (row.status !== actualStatus) {
                db.run(`UPDATE Accounts SET status = ? WHERE id = ?`, [actualStatus, row.id]);
            }

            return {
                id: row.id,
                login: row.login,
                status: actualStatus,
                current_code: current_code,
                last_drop_time: row.last_drop_time
            };
        });
        
        res.json(accounts);
    });
});

// Test Launch CS2 via Docker
app.post('/api/accounts/:id/test-launch', (req, res) => {
    const accountId = req.params.id;
    
    db.get(`SELECT * FROM Accounts WHERE id = ?`, [accountId], async (err, account) => {
        if (err || !account) {
            return res.status(404).json({ error: 'Account not found' });
        }
        
        try {
            // Generate a unique client port based on the ID
            const clientPort = 27000 + account.id; 
            
            await dockerManager.launchAccount(account, clientPort);
            
            db.run(`UPDATE Accounts SET status = 'running' WHERE id = ?`, [accountId]);
            res.json({ success: true, message: \`Docker container launched on client port \${clientPort}\` });
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    });
});

// Stop CS2 Docker Container
app.post('/api/accounts/:id/stop', async (req, res) => {
    const accountId = req.params.id;
    
    try {
        await dockerManager.stopAccount(accountId);
        db.run(`UPDATE Accounts SET status = 'idle' WHERE id = ?`, [accountId]);
        res.json({ success: true, message: 'Container annihilated.' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

app.listen(PORT, () => {
    console.log(\`Docker Orchestrator MVP running on http://localhost:\${PORT}\`);
});
