const { spawn } = require('child_process');
const os = require('os');

const processes = {};
let nextClientPort = 27015;

// IMPORTANT: Set this to your actual CS2 path on the Windows Server
const CS2_PATH = process.env.CS2_PATH || 'C:\\Program Files (x86)\\Steam\\steamapps\\common\\Counter-Strike Global Offensive\\game\\bin\\win64\\cs2.exe';

class ProcessManager {
    launch(accountId, serverIp = '127.0.0.1:27015') {
        if (processes[accountId]) {
            throw new Error('Process is already running for this account.');
        }

        const clientPort = nextClientPort++;
        
        // Constructing the CS2 launch arguments
        const args = [
            '-textmode',
            '-novid',
            '-nosound',
            '-low',
            '+clientport', clientPort.toString(),
            '+fps_max', '10',
            '+connect', serverIp
        ];

        console.log(`[ProcessManager] Launching CS2 for account ${accountId} on port ${clientPort}...`);
        
        // Spawn the process
        // Note: On Windows, we use detached: true so it runs independently
        const cs2Process = spawn(CS2_PATH, args, { 
            detached: true,
            stdio: 'ignore' // Ignore stdio to run completely in background
        });

        // Store the process reference
        processes[accountId] = cs2Process;

        cs2Process.on('error', (err) => {
            console.error(`[ProcessManager] Failed to start CS2 for account ${accountId}:`, err);
            delete processes[accountId];
        });

        cs2Process.on('exit', (code) => {
            console.log(`[ProcessManager] CS2 for account ${accountId} exited with code ${code}`);
            delete processes[accountId];
        });

        // Unref the process so the Node event loop doesn't wait for it
        cs2Process.unref();

        return clientPort;
    }

    stop(accountId) {
        const proc = processes[accountId];
        if (proc) {
            console.log(`[ProcessManager] Stopping CS2 for account ${accountId}...`);
            // On Windows, taskkill is often more reliable for forceful termination of GUI apps
            if (os.platform() === 'win32') {
                const { exec } = require('child_process');
                exec(`taskkill /pid ${proc.pid} /f /t`);
            } else {
                proc.kill('SIGKILL');
            }
            delete processes[accountId];
            return true;
        }
        return false;
    }

    isRunning(accountId) {
        return !!processes[accountId];
    }
}

module.exports = new ProcessManager();
